package compiler;

import java_cup.runtime.Symbol;

%%

%class Yylex
%cup
%line

%{
    private Symbol symbol(int type) {
        return new Symbol(type, yyline + 1, 0);
    }

    private Symbol symbol(int type, Object value) {
        return new Symbol(type, yyline + 1, 0, value);
    }

    private String unquote(String text) {
        return text.substring(1, text.length() - 1);
    }
%}

%eofval{
    return symbol(sym.EOF);
%eofval}

LETTER = [a-zA-Z]
DIGIT = [0-9]
WHITESPACE = [ \t\f]+
EOL = \r\n|\r|\n
NUMBER = {DIGIT}+(\.{DIGIT}+)?
STRING = \"([^\"\\]|\\.)*\"
IDENTIFIER_NUM = {LETTER}{LETTER}{DIGIT}
IDENTIFIER_TEXT = {LETTER}{LETTER}\$

%%

{WHITESPACE}        { /* ignore whitespace */ }
{EOL}               { return symbol(sym.EOL); }

"begin"            { return symbol(sym.BEGIN); }
"name"             { return symbol(sym.NAME); }
"id"               { return symbol(sym.ID_KEYWORD); }
"declare"          { return symbol(sym.DECLARE); }
"num"              { return symbol(sym.NUM); }
"text"             { return symbol(sym.TEXT); }
"start"            { return symbol(sym.START); }
"end"              { return symbol(sym.END); }

"input"            { return symbol(sym.INPUT); }
"print"            { return symbol(sym.PRINT); }
"if"               { return symbol(sym.IF); }
"else"             { return symbol(sym.ELSE); }
"endif"            { return symbol(sym.ENDIF); }

"repeat"           { return symbol(sym.REPEAT); }
"times"            { return symbol(sym.TIMES); }
"until"            { return symbol(sym.UNTIL); }
"endrepeat"        { return symbol(sym.ENDREPEAT); }
"from"             { return symbol(sym.FROM); }
"to"               { return symbol(sym.TO); }

">="               { return symbol(sym.GE); }
"<="               { return symbol(sym.LE); }
"=="               { return symbol(sym.EQ); }
"!="               { return symbol(sym.NE); }
">"                { return symbol(sym.GT); }
"<"                { return symbol(sym.LT); }

"="                { return symbol(sym.ASSIGN); }
"+"                { return symbol(sym.PLUS); }
"-"                { return symbol(sym.MINUS); }
"*"                { return symbol(sym.TIMES_OP); }
"/"                { return symbol(sym.DIVIDE); }
","                { return symbol(sym.COMMA); }
"("                { return symbol(sym.LPAREN); }
")"                { return symbol(sym.RPAREN); }

{NUMBER}           { return symbol(sym.NUMBER, Double.valueOf(yytext())); }
{STRING}           { return symbol(sym.STRING, unquote(yytext())); }
{IDENTIFIER_NUM}   { return symbol(sym.IDENTIFIER_NUM, yytext()); }
{IDENTIFIER_TEXT}  { return symbol(sym.IDENTIFIER_TEXT, yytext()); }

.                  {
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
