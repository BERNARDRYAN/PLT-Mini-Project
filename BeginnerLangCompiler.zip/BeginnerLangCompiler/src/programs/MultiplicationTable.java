import java.util.Scanner;

// Programmer: LIM KAI SHEN
// ID: 1211110602

public class MultiplicationTable {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double aa1 = 0;
        double bb1 = 0;
        double cc1 = 0;

        System.out.print("Enter multiplication table number: ");
        aa1 = sc.nextDouble();
        bb1 = 1.0;
        for (int loop1 = 0; loop1 < 12.0; loop1++) {
            cc1 = aa1 * bb1;
            System.out.println(aa1 + " x " + bb1 + " = " + cc1);
            bb1 = bb1 + 1.0;
        }
    }
}
