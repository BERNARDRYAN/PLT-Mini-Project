import java.util.Scanner;

// Programmer: BERNARD RYAN SIM KANG XUAN
// ID: 1221101777

public class Calculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double aa1 = 0;
        double bb1 = 0;
        double op1 = 0;
        double rr1 = 0;

        System.out.print("Enter first number: ");
        aa1 = sc.nextDouble();
        System.out.print("Enter second number: ");
        bb1 = sc.nextDouble();
        System.out.print("Choose 1 add, 2 subtract, 3 multiply, 4 divide: ");
        op1 = sc.nextDouble();
        if (op1 == 1.0) {
            rr1 = aa1 + bb1;
            System.out.println("Addition result: " + rr1);
        }
        if (op1 == 2.0) {
            rr1 = aa1 - bb1;
            System.out.println("Subtraction result: " + rr1);
        }
        if (op1 == 3.0) {
            rr1 = aa1 * bb1;
            System.out.println("Multiplication result: " + rr1);
        }
        if (op1 == 4.0) {
            rr1 = aa1 / bb1;
            System.out.println("Division result: " + rr1);
        }
    }
}
