import java.util.Scanner;

// Programmer: GOH CHUN YONG
// ID: 241UC24158

public class ShoppingBill {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double ct1 = 0;
        double pr1 = 0;
        double qt1 = 0;
        double it1 = 0;
        double sb1 = 0;
        double ds1 = 0;
        double tx1 = 0;
        double tt1 = 0;

        System.out.print("Enter number of items: ");
        ct1 = sc.nextDouble();
        sb1 = 0.0;
        for (int loop1 = 0; loop1 < ct1; loop1++) {
            System.out.print("Enter item price: ");
            pr1 = sc.nextDouble();
            System.out.print("Enter item quantity: ");
            qt1 = sc.nextDouble();
            it1 = pr1 * qt1;
            sb1 = sb1 + it1;
            System.out.println("Item total: RM " + it1);
        }
        ds1 = 0.0;
        tx1 = sb1 * 0.06;
        tt1 = sb1 + tx1;
        if (sb1 >= 100.0) {
            ds1 = sb1 * 0.1;
            tt1 = sb1 - ds1 + tx1;
        }
        System.out.println("Subtotal: RM " + sb1);
        System.out.println("Discount: RM " + ds1);
        System.out.println("Tax: RM " + tx1);
        System.out.println("Final total: RM " + tt1);
    }
}
