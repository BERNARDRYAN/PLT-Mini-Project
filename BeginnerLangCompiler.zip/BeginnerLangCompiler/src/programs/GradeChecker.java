import java.util.Scanner;

// Programmer: GOH CHUN YONG
// ID: 241UC24158

public class GradeChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double mk1 = 0;

        System.out.print("Enter student mark: ");
        mk1 = sc.nextDouble();
        System.out.println("Mark entered: " + mk1);
        if (mk1 < 0.0) {
            System.out.println("Invalid mark. Mark cannot be below 0.");
        }
        if (mk1 > 100.0) {
            System.out.println("Invalid mark. Mark cannot be above 100.");
        }
        if (mk1 >= 80.0) {
            if (mk1 <= 100.0) {
                System.out.println("Grade: A");
                System.out.println("Status: Excellent");
            }
        }
        if (mk1 >= 70.0) {
            if (mk1 < 80.0) {
                System.out.println("Grade: B");
                System.out.println("Status: Good");
            }
        }
        if (mk1 >= 60.0) {
            if (mk1 < 70.0) {
                System.out.println("Grade: C");
                System.out.println("Status: Satisfactory");
            }
        }
        if (mk1 >= 50.0) {
            if (mk1 < 60.0) {
                System.out.println("Grade: D");
                System.out.println("Status: Pass");
            }
        }
        if (mk1 >= 0.0) {
            if (mk1 < 50.0) {
                System.out.println("Grade: F");
                System.out.println("Status: Fail");
            }
        }
    }
}
