package compiler;

import java.io.FileReader;

public class Main {
    public static void main(String[] args) {
        String inputPath = args.length > 0 ? args[0] : "samples/calculator.bgl";

        try {
            Yylex lexer = new Yylex(new FileReader(inputPath));
            parser cupParser = new parser(lexer);

            cupParser.parse();

            System.out.println("Compilation finished.");
        }
        catch (Exception ex) {
            System.err.println("Compilation failed.");
            System.err.println(ex.getMessage());
        }
    }
}