package compiler;
import java_cup.runtime.Symbol;


class Yylex implements java_cup.runtime.Scanner {
	private final int YY_BUFFER_SIZE = 512;
	private final int YY_F = -1;
	private final int YY_NO_STATE = -1;
	private final int YY_NOT_ACCEPT = 0;
	private final int YY_START = 1;
	private final int YY_END = 2;
	private final int YY_NO_ANCHOR = 4;
	private final int YY_BOL = 128;
	private final int YY_EOF = 129;

    private Symbol symbol(int type) {
        return new Symbol(type, yyline + 1, 0);
    }
    private Symbol symbol(int type, Object value) {
        return new Symbol(type, yyline + 1, 0, value);
    }
    private String unquote(String text) {
        return text.substring(1, text.length() - 1);
    }
	private java.io.BufferedReader yy_reader;
	private int yy_buffer_index;
	private int yy_buffer_read;
	private int yy_buffer_start;
	private int yy_buffer_end;
	private char yy_buffer[];
	private int yyline;
	private boolean yy_at_bol;
	private int yy_lexical_state;

	Yylex (java.io.Reader reader) {
		this ();
		if (null == reader) {
			throw (new Error("Error: Bad input stream initializer."));
		}
		yy_reader = new java.io.BufferedReader(reader);
	}

	Yylex (java.io.InputStream instream) {
		this ();
		if (null == instream) {
			throw (new Error("Error: Bad input stream initializer."));
		}
		yy_reader = new java.io.BufferedReader(new java.io.InputStreamReader(instream));
	}

	private Yylex () {
		yy_buffer = new char[YY_BUFFER_SIZE];
		yy_buffer_read = 0;
		yy_buffer_index = 0;
		yy_buffer_start = 0;
		yy_buffer_end = 0;
		yyline = 0;
		yy_at_bol = true;
		yy_lexical_state = YYINITIAL;
	}

	private boolean yy_eof_done = false;
	private final int YYINITIAL = 0;
	private final int yy_state_dtrans[] = {
		0
	};
	private void yybegin (int state) {
		yy_lexical_state = state;
	}
	private int yy_advance ()
		throws java.io.IOException {
		int next_read;
		int i;
		int j;

		if (yy_buffer_index < yy_buffer_read) {
			return yy_buffer[yy_buffer_index++];
		}

		if (0 != yy_buffer_start) {
			i = yy_buffer_start;
			j = 0;
			while (i < yy_buffer_read) {
				yy_buffer[j] = yy_buffer[i];
				++i;
				++j;
			}
			yy_buffer_end = yy_buffer_end - yy_buffer_start;
			yy_buffer_start = 0;
			yy_buffer_read = j;
			yy_buffer_index = j;
			next_read = yy_reader.read(yy_buffer,
					yy_buffer_read,
					yy_buffer.length - yy_buffer_read);
			if (-1 == next_read) {
				return YY_EOF;
			}
			yy_buffer_read = yy_buffer_read + next_read;
		}

		while (yy_buffer_index >= yy_buffer_read) {
			if (yy_buffer_index >= yy_buffer.length) {
				yy_buffer = yy_double(yy_buffer);
			}
			next_read = yy_reader.read(yy_buffer,
					yy_buffer_read,
					yy_buffer.length - yy_buffer_read);
			if (-1 == next_read) {
				return YY_EOF;
			}
			yy_buffer_read = yy_buffer_read + next_read;
		}
		return yy_buffer[yy_buffer_index++];
	}
	private void yy_move_end () {
		if (yy_buffer_end > yy_buffer_start &&
		    '\n' == yy_buffer[yy_buffer_end-1])
			yy_buffer_end--;
		if (yy_buffer_end > yy_buffer_start &&
		    '\r' == yy_buffer[yy_buffer_end-1])
			yy_buffer_end--;
	}
	private boolean yy_last_was_cr=false;
	private void yy_mark_start () {
		int i;
		for (i = yy_buffer_start; i < yy_buffer_index; ++i) {
			if ('\n' == yy_buffer[i] && !yy_last_was_cr) {
				++yyline;
			}
			if ('\r' == yy_buffer[i]) {
				++yyline;
				yy_last_was_cr=true;
			} else yy_last_was_cr=false;
		}
		yy_buffer_start = yy_buffer_index;
	}
	private void yy_mark_end () {
		yy_buffer_end = yy_buffer_index;
	}
	private void yy_to_mark () {
		yy_buffer_index = yy_buffer_end;
		yy_at_bol = (yy_buffer_end > yy_buffer_start) &&
		            ('\r' == yy_buffer[yy_buffer_end-1] ||
		             '\n' == yy_buffer[yy_buffer_end-1] ||
		             2028/*LS*/ == yy_buffer[yy_buffer_end-1] ||
		             2029/*PS*/ == yy_buffer[yy_buffer_end-1]);
	}
	private java.lang.String yytext () {
		return (new java.lang.String(yy_buffer,
			yy_buffer_start,
			yy_buffer_end - yy_buffer_start));
	}
	private int yylength () {
		return yy_buffer_end - yy_buffer_start;
	}
	private char[] yy_double (char buf[]) {
		int i;
		char newbuf[];
		newbuf = new char[2*buf.length];
		for (i = 0; i < buf.length; ++i) {
			newbuf[i] = buf[i];
		}
		return newbuf;
	}
	private final int YY_E_INTERNAL = 0;
	private final int YY_E_MATCH = 1;
	private java.lang.String yy_error_string[] = {
		"Error: Internal error.\n",
		"Error: Unmatched input.\n"
	};
	private void yy_error (int code,boolean fatal) {
		java.lang.System.out.print(yy_error_string[code]);
		java.lang.System.out.flush();
		if (fatal) {
			throw new Error("Fatal Error.\n");
		}
	}
	private int[][] unpackFromString(int size1, int size2, String st) {
		int colonIndex = -1;
		String lengthString;
		int sequenceLength = 0;
		int sequenceInteger = 0;

		int commaIndex;
		String workString;

		int res[][] = new int[size1][size2];
		for (int i= 0; i < size1; i++) {
			for (int j= 0; j < size2; j++) {
				if (sequenceLength != 0) {
					res[i][j] = sequenceInteger;
					sequenceLength--;
					continue;
				}
				commaIndex = st.indexOf(',');
				workString = (commaIndex==-1) ? st :
					st.substring(0, commaIndex);
				st = st.substring(commaIndex+1);
				colonIndex = workString.indexOf(':');
				if (colonIndex == -1) {
					res[i][j]=Integer.parseInt(workString);
					continue;
				}
				lengthString =
					workString.substring(colonIndex+1);
				sequenceLength=Integer.parseInt(lengthString);
				workString=workString.substring(0,colonIndex);
				sequenceInteger=Integer.parseInt(workString);
				res[i][j] = sequenceInteger;
				sequenceLength--;
			}
		}
		return res;
	}
	private int yy_acpt[] = {
		/* 0 */ YY_NOT_ACCEPT,
		/* 1 */ YY_NO_ANCHOR,
		/* 2 */ YY_NO_ANCHOR,
		/* 3 */ YY_NO_ANCHOR,
		/* 4 */ YY_NO_ANCHOR,
		/* 5 */ YY_NO_ANCHOR,
		/* 6 */ YY_NO_ANCHOR,
		/* 7 */ YY_NO_ANCHOR,
		/* 8 */ YY_NO_ANCHOR,
		/* 9 */ YY_NO_ANCHOR,
		/* 10 */ YY_NO_ANCHOR,
		/* 11 */ YY_NO_ANCHOR,
		/* 12 */ YY_NO_ANCHOR,
		/* 13 */ YY_NO_ANCHOR,
		/* 14 */ YY_NO_ANCHOR,
		/* 15 */ YY_NO_ANCHOR,
		/* 16 */ YY_NO_ANCHOR,
		/* 17 */ YY_NO_ANCHOR,
		/* 18 */ YY_NO_ANCHOR,
		/* 19 */ YY_NO_ANCHOR,
		/* 20 */ YY_NO_ANCHOR,
		/* 21 */ YY_NO_ANCHOR,
		/* 22 */ YY_NO_ANCHOR,
		/* 23 */ YY_NO_ANCHOR,
		/* 24 */ YY_NO_ANCHOR,
		/* 25 */ YY_NO_ANCHOR,
		/* 26 */ YY_NO_ANCHOR,
		/* 27 */ YY_NO_ANCHOR,
		/* 28 */ YY_NO_ANCHOR,
		/* 29 */ YY_NO_ANCHOR,
		/* 30 */ YY_NO_ANCHOR,
		/* 31 */ YY_NO_ANCHOR,
		/* 32 */ YY_NO_ANCHOR,
		/* 33 */ YY_NO_ANCHOR,
		/* 34 */ YY_NO_ANCHOR,
		/* 35 */ YY_NO_ANCHOR,
		/* 36 */ YY_NO_ANCHOR,
		/* 37 */ YY_NO_ANCHOR,
		/* 38 */ YY_NO_ANCHOR,
		/* 39 */ YY_NO_ANCHOR,
		/* 40 */ YY_NO_ANCHOR,
		/* 41 */ YY_NO_ANCHOR,
		/* 42 */ YY_NOT_ACCEPT,
		/* 43 */ YY_NO_ANCHOR,
		/* 44 */ YY_NO_ANCHOR,
		/* 45 */ YY_NO_ANCHOR,
		/* 46 */ YY_NOT_ACCEPT,
		/* 47 */ YY_NO_ANCHOR,
		/* 48 */ YY_NOT_ACCEPT,
		/* 49 */ YY_NO_ANCHOR,
		/* 50 */ YY_NOT_ACCEPT,
		/* 51 */ YY_NO_ANCHOR,
		/* 52 */ YY_NOT_ACCEPT,
		/* 53 */ YY_NO_ANCHOR,
		/* 54 */ YY_NOT_ACCEPT,
		/* 55 */ YY_NOT_ACCEPT,
		/* 56 */ YY_NOT_ACCEPT,
		/* 57 */ YY_NOT_ACCEPT,
		/* 58 */ YY_NOT_ACCEPT,
		/* 59 */ YY_NOT_ACCEPT,
		/* 60 */ YY_NOT_ACCEPT,
		/* 61 */ YY_NOT_ACCEPT,
		/* 62 */ YY_NOT_ACCEPT,
		/* 63 */ YY_NOT_ACCEPT,
		/* 64 */ YY_NOT_ACCEPT,
		/* 65 */ YY_NOT_ACCEPT,
		/* 66 */ YY_NOT_ACCEPT,
		/* 67 */ YY_NOT_ACCEPT,
		/* 68 */ YY_NOT_ACCEPT,
		/* 69 */ YY_NOT_ACCEPT,
		/* 70 */ YY_NOT_ACCEPT,
		/* 71 */ YY_NOT_ACCEPT,
		/* 72 */ YY_NOT_ACCEPT,
		/* 73 */ YY_NOT_ACCEPT,
		/* 74 */ YY_NOT_ACCEPT,
		/* 75 */ YY_NOT_ACCEPT,
		/* 76 */ YY_NOT_ACCEPT,
		/* 77 */ YY_NOT_ACCEPT,
		/* 78 */ YY_NOT_ACCEPT,
		/* 79 */ YY_NOT_ACCEPT,
		/* 80 */ YY_NOT_ACCEPT,
		/* 81 */ YY_NOT_ACCEPT,
		/* 82 */ YY_NOT_ACCEPT,
		/* 83 */ YY_NOT_ACCEPT,
		/* 84 */ YY_NOT_ACCEPT,
		/* 85 */ YY_NOT_ACCEPT,
		/* 86 */ YY_NOT_ACCEPT,
		/* 87 */ YY_NOT_ACCEPT,
		/* 88 */ YY_NOT_ACCEPT,
		/* 89 */ YY_NOT_ACCEPT,
		/* 90 */ YY_NO_ANCHOR,
		/* 91 */ YY_NOT_ACCEPT,
		/* 92 */ YY_NOT_ACCEPT,
		/* 93 */ YY_NOT_ACCEPT,
		/* 94 */ YY_NOT_ACCEPT,
		/* 95 */ YY_NOT_ACCEPT,
		/* 96 */ YY_NO_ANCHOR,
		/* 97 */ YY_NOT_ACCEPT,
		/* 98 */ YY_NO_ANCHOR,
		/* 99 */ YY_NO_ANCHOR,
		/* 100 */ YY_NO_ANCHOR,
		/* 101 */ YY_NO_ANCHOR,
		/* 102 */ YY_NO_ANCHOR,
		/* 103 */ YY_NO_ANCHOR,
		/* 104 */ YY_NO_ANCHOR
	};
	private int yy_cmap[] = unpackFromString(1,130,
"36:9,1,3,36,1,2,36:18,1,25,35,36,39,36:3,31,32,28,26,30,27,34,29,33:10,36:2" +
",24,23,22,36:2,38:26,36,37,36:4,9,4,12,11,5,20,6,38,7,38:2,13,10,8,21,19,38" +
",14,18,16,15,38:2,17,38:2,36:5,0:2")[0];

	private int yy_rmap[] = unpackFromString(1,105,
"0,1,2,3,4,5,6,7,1:7,8,9:3,1:7,10,1:15,9,1,11,12,13,14,15,16,17,1,18,19,20,2" +
"1,22,23,24,25,26,27,12,19,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,4" +
"4,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68")[0];

	private int yy_nxt[][] = unpackFromString(69,40,
"1,2,3,43,4,90,96,44,98,96:2,99,96:2,100,101,47,96,102,103,104,96,5,6,7,49,8" +
",9,10,11,12,13,14,15,51,53,51:2,96,51,-1:41,2,-1:41,43,-1:40,42,46,42:16,-1" +
":16,42,-1:24,19,-1:39,20,-1:39,21,-1:49,15,62,-1:38,24,-1:5,25,-1:7,76,-1:6" +
",97,-1:29,42:4,52,42:2,16,42:8,17,42,-1:16,42,-1:34,45,-1:12,65,-1:26,24,-1" +
":5,25,-1:4,42,58,42,92,42:13,18,-1:16,42,-1:12,26,-1:21,24,-1:5,25,-1:23,22" +
",-1:34,66,-1:14,24,-1:5,25,-1:19,67,-1:13,24,-1:5,25,-1,63:34,23,63,64,63:2" +
",-1:10,68,-1:22,24,-1:5,25,-1:10,27,-1:22,24,-1:5,25,-1:12,69,-1:20,24,-1:5" +
",25,-1:16,93,-1:16,24,-1:5,25,-1:17,71,-1:15,24,-1:5,25,-1:9,72,-1:23,24,-1" +
":5,25,-1:7,73,-1:25,24,-1:5,25,-1:21,74,-1:11,24,-1:5,25,-1,63,-1:2,63:36,-" +
"1:7,75,-1:37,28,-1:49,77,-1:29,29,-1:47,78,-1:31,95,-1:50,30,-1:37,81,-1:33" +
",82,-1:41,31,-1:37,32,-1:51,33,-1:35,34,-1:32,84,-1:43,35,-1:44,36,-1:37,37" +
",-1:39,38,-1:42,86,-1:34,87,-1:41,39,-1:28,88,-1:39,40,-1:43,89,-1:46,41,-1" +
":27,42:4,48,42:4,50,42:8,-1:16,42,-1:20,70,-1:13,24,-1:5,25,-1:10,94,-1:22," +
"24,-1:5,25,-1:7,79,-1:37,80,-1:43,85,-1:34,42:18,-1:16,42,-1:6,83,-1:38,42:" +
"5,54,42:5,55,42:6,-1:16,42,-1:5,42,56,42:16,-1:16,42,-1:5,42,91,42:16,-1:16" +
",42,-1:5,42:4,57,42:13,-1:16,42,-1:5,42:12,59,42:5,-1:16,42,-1:5,42:10,60,4" +
"2:7,-1:16,42,-1:5,42:10,61,42:7,-1:16,42,-1");

	public java_cup.runtime.Symbol next_token ()
		throws java.io.IOException {
		int yy_lookahead;
		int yy_anchor = YY_NO_ANCHOR;
		int yy_state = yy_state_dtrans[yy_lexical_state];
		int yy_next_state = YY_NO_STATE;
		int yy_last_accept_state = YY_NO_STATE;
		boolean yy_initial = true;
		int yy_this_accept;

		yy_mark_start();
		yy_this_accept = yy_acpt[yy_state];
		if (YY_NOT_ACCEPT != yy_this_accept) {
			yy_last_accept_state = yy_state;
			yy_mark_end();
		}
		while (true) {
			if (yy_initial && yy_at_bol) yy_lookahead = YY_BOL;
			else yy_lookahead = yy_advance();
			yy_next_state = YY_F;
			yy_next_state = yy_nxt[yy_rmap[yy_state]][yy_cmap[yy_lookahead]];
			if (YY_EOF == yy_lookahead && true == yy_initial) {

    return symbol(sym.EOF);
			}
			if (YY_F != yy_next_state) {
				yy_state = yy_next_state;
				yy_initial = false;
				yy_this_accept = yy_acpt[yy_state];
				if (YY_NOT_ACCEPT != yy_this_accept) {
					yy_last_accept_state = yy_state;
					yy_mark_end();
				}
			}
			else {
				if (YY_NO_STATE == yy_last_accept_state) {
					throw (new Error("Lexical Error: Unmatched Input."));
				}
				else {
					yy_anchor = yy_acpt[yy_last_accept_state];
					if (0 != (YY_END & yy_anchor)) {
						yy_move_end();
					}
					yy_to_mark();
					switch (yy_last_accept_state) {
					case 1:
						
					case -2:
						break;
					case 2:
						{ /* ignore whitespace */ }
					case -3:
						break;
					case 3:
						{ return symbol(sym.EOL); }
					case -4:
						break;
					case 4:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -5:
						break;
					case 5:
						{ return symbol(sym.GT); }
					case -6:
						break;
					case 6:
						{ return symbol(sym.ASSIGN); }
					case -7:
						break;
					case 7:
						{ return symbol(sym.LT); }
					case -8:
						break;
					case 8:
						{ return symbol(sym.PLUS); }
					case -9:
						break;
					case 9:
						{ return symbol(sym.MINUS); }
					case -10:
						break;
					case 10:
						{ return symbol(sym.TIMES_OP); }
					case -11:
						break;
					case 11:
						{ return symbol(sym.DIVIDE); }
					case -12:
						break;
					case 12:
						{ return symbol(sym.COMMA); }
					case -13:
						break;
					case 13:
						{ return symbol(sym.LPAREN); }
					case -14:
						break;
					case 14:
						{ return symbol(sym.RPAREN); }
					case -15:
						break;
					case 15:
						{ return symbol(sym.NUMBER, Double.valueOf(yytext())); }
					case -16:
						break;
					case 16:
						{ return symbol(sym.ID_KEYWORD); }
					case -17:
						break;
					case 17:
						{ return symbol(sym.IF); }
					case -18:
						break;
					case 18:
						{ return symbol(sym.TO); }
					case -19:
						break;
					case 19:
						{ return symbol(sym.GE); }
					case -20:
						break;
					case 20:
						{ return symbol(sym.EQ); }
					case -21:
						break;
					case 21:
						{ return symbol(sym.LE); }
					case -22:
						break;
					case 22:
						{ return symbol(sym.NE); }
					case -23:
						break;
					case 23:
						{ return symbol(sym.STRING, unquote(yytext())); }
					case -24:
						break;
					case 24:
						{ return symbol(sym.IDENTIFIER_NUM, yytext()); }
					case -25:
						break;
					case 25:
						{ return symbol(sym.IDENTIFIER_TEXT, yytext()); }
					case -26:
						break;
					case 26:
						{ return symbol(sym.END); }
					case -27:
						break;
					case 27:
						{ return symbol(sym.NUM); }
					case -28:
						break;
					case 28:
						{ return symbol(sym.ELSE); }
					case -29:
						break;
					case 29:
						{ return symbol(sym.NAME); }
					case -30:
						break;
					case 30:
						{ return symbol(sym.TEXT); }
					case -31:
						break;
					case 31:
						{ return symbol(sym.FROM); }
					case -32:
						break;
					case 32:
						{ return symbol(sym.BEGIN); }
					case -33:
						break;
					case 33:
						{ return symbol(sym.ENDIF); }
					case -34:
						break;
					case 34:
						{ return symbol(sym.INPUT); }
					case -35:
						break;
					case 35:
						{ return symbol(sym.UNTIL); }
					case -36:
						break;
					case 36:
						{ return symbol(sym.TIMES); }
					case -37:
						break;
					case 37:
						{ return symbol(sym.START); }
					case -38:
						break;
					case 38:
						{ return symbol(sym.PRINT); }
					case -39:
						break;
					case 39:
						{ return symbol(sym.REPEAT); }
					case -40:
						break;
					case 40:
						{ return symbol(sym.DECLARE); }
					case -41:
						break;
					case 41:
						{ return symbol(sym.ENDREPEAT); }
					case -42:
						break;
					case 43:
						{ return symbol(sym.EOL); }
					case -43:
						break;
					case 44:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -44:
						break;
					case 45:
						{ return symbol(sym.NUMBER, Double.valueOf(yytext())); }
					case -45:
						break;
					case 47:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -46:
						break;
					case 49:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -47:
						break;
					case 51:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -48:
						break;
					case 53:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -49:
						break;
					case 90:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -50:
						break;
					case 96:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -51:
						break;
					case 98:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -52:
						break;
					case 99:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -53:
						break;
					case 100:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -54:
						break;
					case 101:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -55:
						break;
					case 102:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -56:
						break;
					case 103:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -57:
						break;
					case 104:
						{
                       System.err.println(
                           "Illegal character '" + yytext() + "' at line " +
                           (yyline + 1)
                       );
                   }
					case -58:
						break;
					default:
						yy_error(YY_E_INTERNAL,false);
					case -1:
					}
					yy_initial = true;
					yy_state = yy_state_dtrans[yy_lexical_state];
					yy_next_state = YY_NO_STATE;
					yy_last_accept_state = YY_NO_STATE;
					yy_mark_start();
					yy_this_accept = yy_acpt[yy_state];
					if (YY_NOT_ACCEPT != yy_this_accept) {
						yy_last_accept_state = yy_state;
						yy_mark_end();
					}
				}
			}
		}
	}
}
