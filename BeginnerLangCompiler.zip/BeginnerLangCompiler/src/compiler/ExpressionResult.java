package compiler;

public class ExpressionResult {
    public final String code;

    public ExpressionResult(String code) {
        this.code = code;
    }
}