package compiler;

public class CodeGenerator {
    private StringBuilder comments = new StringBuilder();
    private StringBuilder declarations = new StringBuilder();
    private StringBuilder statements = new StringBuilder();

    private int indentLevel = 2;
    private int loopCounter = 0;

    private String indent() {
        String result = "";
        for (int i = 0; i < indentLevel; i++) {
            result += "    ";
        }
        return result;
    }

    public void addMember(String name, String id) {
        comments.append("// Programmer: ").append(name).append("\n");

        if (id != null && !id.isEmpty()) {
            comments.append("// ID: ").append(id).append("\n");
        }

        comments.append("\n");
    }

    public void declareNum(String name) {
        declarations.append("        double ").append(name).append(" = 0;\n");
    }

    public void declareText(String name) {
        declarations.append("        String ").append(toJavaName(name)).append(" = \"\";\n");
    }

    public void addStatement(String code) {
        statements.append(indent()).append(code).append("\n");
    }

    public void beginBlock(String header) {
        addStatement(header + " {");
        indentLevel++;
    }

    public void endBlock() {
        indentLevel--;
        addStatement("}");
    }

    public void endDoUntilBlock(String condition) {
        indentLevel--;
        addStatement("} while (!(" + condition + "));");
    }

    public void elseBlock() {
        indentLevel--;
        addStatement("} else {");
        indentLevel++;
    }

    public String nextLoopName() {
        loopCounter++;
        return "loop" + loopCounter;
    }

    public String toJavaName(String name) {
        return name.replace("$", "_text");
    }

    public String escapeJavaString(String value) {
        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"");
    }

    public String buildProgram() {
        return ""
            + "import java.util.Scanner;\n\n"
            + comments.toString()
            + "public class GeneratedProgram {\n"
            + "    public static void main(String[] args) {\n"
            + "        Scanner sc = new Scanner(System.in);\n\n"
            + declarations.toString()
            + "\n"
            + statements.toString()
            + "    }\n"
            + "}\n";
    }
}