package compiler;

public class ConditionResult {
    public final String code;

    public ConditionResult(String code) {
        this.code = code;
    }
}