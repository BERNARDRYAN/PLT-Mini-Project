package compiler;

public class SemanticAnalyzer {
    private final SymbolTable symbols = new SymbolTable();

    public void declareNum(String name) {
        symbols.declare(name, "num");
    }

    public void declareText(String name) {
        symbols.declare(name, "text");
    }

    public void useNum(String name) {
        symbols.requireType(name, "num");
    }

    public void useText(String name) {
        symbols.requireType(name, "text");
    }

    public void inputNum(String name) {
        useNum(name);
    }

    public void inputText(String name) {
        useText(name);
    }

    public void assignNum(String name) {
        useNum(name);
    }

    public void assignText(String name) {
        useText(name);
    }
}