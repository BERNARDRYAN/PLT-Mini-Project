package compiler;

import java.util.HashMap;
import java.util.Map;

public class SymbolTable {
    private final Map<String, String> variables = new HashMap<>();

    public void declare(String name, String type) {
        if (variables.containsKey(name)) {
            throw new RuntimeException("Semantic error: variable '" + name + "' already declared.");
        }
        variables.put(name, type);
    }

    public void requireDeclared(String name) {
        if (!variables.containsKey(name)) {
            throw new RuntimeException("Semantic error: variable '" + name + "' is not declared.");
        }
    }

    public void requireType(String name, String expectedType) {
        requireDeclared(name);

        String actualType = variables.get(name);
        if (!actualType.equals(expectedType)) {
            throw new RuntimeException(
                "Semantic error: variable '" + name + "' must be " + expectedType +
                " but found " + actualType + "."
            );
        }
    }

    public String getType(String name) {
        requireDeclared(name);
        return variables.get(name);
    }
}