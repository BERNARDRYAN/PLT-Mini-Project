package simpleexample;

import java.util.ArrayList;

public class Parser {

    private ArrayList<Yytoken> tokens;
    private int current = 0;

    public Parser(ArrayList<Yytoken> tokens) {
        this.tokens = tokens;
    }

    public void parse() {
        parseProgram();

        if (!isAtEnd()) {
            error("Unexpected token after program end: " + peek().m_text);
        }

        System.out.println("\nSyntax Analysis Successful!");
        System.out.println("The source program follows the grammar.");
    }

    private void parseProgram() {
        match(1, "Expected 'begin' at the start of the program.");

        parseIdentification();

        match(4, "Expected 'declare' section after identification.");
        parseDeclaration();

        match(5, "Expected 'start' before statements.");
        parseStatementList();

        match(6, "Expected 'end' at the end of the program.");
    }

    private void parseIdentification() {
        int count = 0;

        while (check(2)) { // NAME
            match(2, "Expected 'name'.");
            match(33, "Expected programmer name as string after 'name'.");

            if (check(3)) { // ID_KEYWORD
                match(3, "Expected 'id'.");
                match(33, "Expected programmer ID as string after 'id'.");
            }

            count++;
        }

        if (count == 0) {
            error("Expected at least one 'name' in identification section.");
        }
    }

    private void parseDeclaration() {
        boolean hasDeclaration = false;

        if (check(7)) { // NUM
            match(7, "Expected 'num'.");
            parseNumVariableList();
            hasDeclaration = true;
        }

        if (check(8)) { // TEXT
            match(8, "Expected 'text'.");
            parseTextVariableList();
            hasDeclaration = true;
        }

        if (!hasDeclaration) {
            error("Expected variable declaration using 'num' or 'text'.");
        }
    }

    private void parseNumVariableList() {
        match(34, "Expected numeric variable, example aa1.");

        while (check(30)) { // COMMA
            match(30, "Expected comma.");
            match(34, "Expected numeric variable after comma.");
        }
    }

    private void parseTextVariableList() {
        match(35, "Expected text variable, example aa$.");

        while (check(30)) { // COMMA
            match(30, "Expected comma.");
            match(35, "Expected text variable after comma.");
        }
    }

    private void parseStatementList() {
        while (!isAtEnd() && !check(6) && !check(12) && !check(13) && !check(18)) {
            parseStatement();
        }
    }

    private void parseStatement() {
        if (check(9)) {
            parseInput();
        } 
        else if (check(10)) {
            parsePrint();
        } 
        else if (check(34)) {
            parseAssignment();
        } 
        else if (check(11)) {
            parseIf();
        } 
        else if (check(14)) {
            parseRepeat();
        } 
        else if (check(16)) {
            parseFromLoop();
        } 
        else {
            error("Invalid statement: " + peek().m_text);
        }
    }

    private void parseInput() {
        match(9, "Expected 'input'.");
        match(33, "Expected prompt message after input.");
        
        if (check(34)) {
            match(34, "Expected numeric variable after input prompt.");
        } 
        else if (check(35)) {
            match(35, "Expected text variable after input prompt.");
        } 
        else {
            error("Expected variable after input prompt.");
        }
    }

    private void parsePrint() {
        match(10, "Expected 'print'.");

        if (check(33)) {
            match(33, "Expected string after print.");

            if (startsExpression()) {
                parseExpression();
            }
        } 
        else {
            parseExpression();
        }
    }

    private void parseAssignment() {
        match(34, "Expected numeric variable at beginning of assignment.");
        match(23, "Expected '=' in assignment statement.");
        parseExpression();
    }

    private void parseIf() {
        match(11, "Expected 'if'.");
        parseCondition();

        parseStatementList();

        if (check(12)) {
            match(12, "Expected 'else'.");
            parseStatementList();
        }

        match(13, "Expected 'endif' to close if statement.");
    }

    private void parseRepeat() {
        match(14, "Expected 'repeat'.");
        parseExpression();
        match(15, "Expected 'times' after repeat expression.");

        parseStatementList();

        match(18, "Expected 'endrepeat' to close repeat statement.");
    }

    private void parseFromLoop() {
        match(16, "Expected 'from'.");
        parseExpression();
        match(17, "Expected 'to' in from-to loop.");
        parseExpression();

        parseStatementList();

        match(18, "Expected 'endrepeat' to close from-to loop.");
    }

    private void parseCondition() {
        parseExpression();

        if (check(19) || check(20) || check(21) || check(22) || check(28) || check(29)) {
            advance();
        } 
        else {
            error("Expected relational operator in condition, example >, <, >=, <=, ==, !=");
        }

        parseExpression();
    }

    private void parseExpression() {
        parseTerm();

        while (check(24) || check(25)) {
            advance();
            parseTerm();
        }
    }

    private void parseTerm() {
        parseFactor();

        while (check(26) || check(27)) {
            advance();
            parseFactor();
        }
    }

    private void parseFactor() {
        if (check(36)) {
            match(36, "Expected number.");
        } 
        else if (check(34)) {
            match(34, "Expected numeric variable.");
        } 
        else if (check(31)) {
            match(31, "Expected '('.");
            parseExpression();
            match(32, "Expected ')' after expression.");
        } 
        else {
            error("Expected number, numeric variable, or expression.");
        }
    }

    private boolean startsExpression() {
        return check(36) || check(34) || check(31);
    }

    private boolean check(int tokenType) {
        if (isAtEnd()) {
            return false;
        }
        return peek().m_index == tokenType;
    }

    private Yytoken peek() {
        return tokens.get(current);
    }

    private Yytoken advance() {
        if (!isAtEnd()) {
            current++;
        }
        return tokens.get(current - 1);
    }

    private void match(int tokenType, String message) {
        if (check(tokenType)) {
            advance();
        } 
        else {
            error(message);
        }
    }

    private boolean isAtEnd() {
        return current >= tokens.size();
    }

    private void error(String message) {
        String nearToken = isAtEnd() ? "EOF" : peek().m_text;
        throw new RuntimeException(
            "\nSyntax Error near token " + current + ": " + nearToken + "\n" + message
        );
    }
}