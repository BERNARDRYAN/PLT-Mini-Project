package simpleexample;

import java.io.*;

class SimpleExample {

    public static void main(String argv[]) throws java.io.IOException {

        File infile = new File("D://BeginLang//InputFile.bgl");

        FileInputStream fin = null;

        try {
            fin = new FileInputStream(infile);

            Yylex yy = new Yylex(fin);
            Yytoken token;

            while ((token = yy.yylex()) != null) {
                System.out.println(token);
            }

            fin.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("File " + infile.getAbsolutePath() +
                    " could not be found on filesystem");
        }
        catch (IOException ioe) {
            System.out.println("Exception while reading the file " + ioe);
        }
    }
}

class Yytoken {

    Yytoken(int index, String text) {
        m_index = index;
        m_text = text;
    }

    public int m_index;
    public String m_text;

    public String toString() {
        return "Token #" + m_index + ": " + m_text;
    }
}

%%

%line

NUM_ID = [a-z][a-z][0-9]
TEXT_ID = [a-z][a-z]\$
NUMBER = [0-9]+
STRING = \"[^\"]*\"
WHITESPACE = [ \t\r\n\f]

%%

"begin"      { return new Yytoken(1, "BEGIN: " + yytext()); }
"name"       { return new Yytoken(2, "NAME: " + yytext()); }
"id"         { return new Yytoken(3, "ID_KEYWORD: " + yytext()); }
"declare"   { return new Yytoken(4, "DECLARE: " + yytext()); }
"start"     { return new Yytoken(5, "START: " + yytext()); }
"end"       { return new Yytoken(6, "END: " + yytext()); }

"num"        { return new Yytoken(7, "NUM: " + yytext()); }
"text"       { return new Yytoken(8, "TEXT: " + yytext()); }

"input"      { return new Yytoken(9, "INPUT: " + yytext()); }
"print"      { return new Yytoken(10, "PRINT: " + yytext()); }

"if"         { return new Yytoken(11, "IF: " + yytext()); }
"else"       { return new Yytoken(12, "ELSE: " + yytext()); }
"endif"      { return new Yytoken(13, "ENDIF: " + yytext()); }

"repeat"     { return new Yytoken(14, "REPEAT: " + yytext()); }
"times"      { return new Yytoken(15, "TIMES: " + yytext()); }
"from"       { return new Yytoken(16, "FROM: " + yytext()); }
"to"         { return new Yytoken(17, "TO: " + yytext()); }
"endrepeat"  { return new Yytoken(18, "ENDREPEAT: " + yytext()); }

">="         { return new Yytoken(19, "GE: " + yytext()); }
"<="         { return new Yytoken(20, "LE: " + yytext()); }
"=="         { return new Yytoken(21, "EQ: " + yytext()); }
"!="         { return new Yytoken(22, "NE: " + yytext()); }

"="          { return new Yytoken(23, "ASSIGN: " + yytext()); }
"+"          { return new Yytoken(24, "PLUS: " + yytext()); }
"-"          { return new Yytoken(25, "MINUS: " + yytext()); }
"*"          { return new Yytoken(26, "TIMES_OP: " + yytext()); }
"/"          { return new Yytoken(27, "DIVIDE: " + yytext()); }

">"          { return new Yytoken(28, "GT: " + yytext()); }
"<"          { return new Yytoken(29, "LT: " + yytext()); }

","          { return new Yytoken(30, "COMMA: " + yytext()); }
"("          { return new Yytoken(31, "LPAREN: " + yytext()); }
")"          { return new Yytoken(32, "RPAREN: " + yytext()); }

{STRING}     { return new Yytoken(33, "STRING: " + yytext()); }
{NUM_ID}     { return new Yytoken(34, "IDENTIFIER_NUM: " + yytext()); }
{TEXT_ID}    { return new Yytoken(35, "IDENTIFIER_TEXT: " + yytext()); }
{NUMBER}     { return new Yytoken(36, "NUMBER: " + yytext()); }

{WHITESPACE}+ { /* ignore whitespace */ }

.            { System.err.println("Illegal Character: " + yytext() + " at line " + yyline); }