package simpleexample;

import java.util.ArrayList;

public class Parser {

    private final ArrayList<Yytoken> tokens;
    private int current = 0;

    public Parser(ArrayList<Yytoken> tokens) {
        this.tokens = tokens;
    }

    public void parse() {
        parseProgram();

        if (!isAtEnd()) {
            error("Unexpected token after program end.");
        }

        System.out.println("\nSyntax Analysis Successful!");
        System.out.println("The source program follows the grammar.");
    }

    private void parseProgram() {
        match("BEGIN", "Expected 'begin' at the start of the program.");
        parseIdentification();
        match("DECLARE", "Expected 'declare' section after identification.");
        parseDeclaration();
        match("START", "Expected 'start' before statements.");
        parseStatementList("END");
        match("END", "Expected 'end' at the end of the program.");
    }

    private void parseIdentification() {
        int count = 0;

        while (check("NAME")) {
            match("NAME", "Expected 'name'.");
            match("STRING", "Expected programmer name as string after 'name'.");

            if (check("ID_KEYWORD")) {
                match("ID_KEYWORD", "Expected 'id'.");
                match("STRING", "Expected programmer ID as string after 'id'.");
            }
            count++;
        }

        if (count == 0) {
            error("Expected at least one 'name' in identification section.");
        }
    }

    private void parseDeclaration() {
        boolean hasDeclaration = false;

        if (check("NUM")) {
            match("NUM", "Expected 'num'.");
            parseNumVariableList();
            hasDeclaration = true;
        }

        if (check("TEXT")) {
            match("TEXT", "Expected 'text'.");
            parseTextVariableList();
            hasDeclaration = true;
        }

        if (!hasDeclaration) {
            error("Expected variable declaration using 'num' or 'text'.");
        }
    }

    private void parseNumVariableList() {
        match("IDENTIFIER_NUM", "Expected numeric variable, example aa1.");

        while (check("COMMA")) {
            match("COMMA", "Expected comma.");
            match("IDENTIFIER_NUM", "Expected numeric variable after comma.");
        }
    }

    private void parseTextVariableList() {
        match("IDENTIFIER_TEXT", "Expected text variable, example aa$.");

        while (check("COMMA")) {
            match("COMMA", "Expected comma.");
            match("IDENTIFIER_TEXT", "Expected text variable after comma.");
        }
    }

    private void parseStatementList(String... stopTokens) {
        while (!isAtEnd() && !isStopToken(stopTokens)) {
            parseStatement();
        }
    }

    private boolean isStopToken(String... stopTokens) {
        for (String stop : stopTokens) {
            if (check(stop)) {
                return true;
            }
        }
        return false;
    }

    private void parseStatement() {
        if (check("INPUT")) {
            parseInput();
        }
        else if (check("PRINT")) {
            parsePrint();
        }
        else if (check("IDENTIFIER_NUM")) {
            parseAssignment();
        }
        else if (check("IF")) {
            parseIf();
        }
        else if (check("REPEAT")) {
            parseRepeat();
        }
        else if (check("FROM")) {
            parseFromLoop();
        }
        else {
            error("Invalid statement.");
        }
    }

    private void parseInput() {
        match("INPUT", "Expected 'input'.");
        match("STRING", "Expected prompt message after input.");

        if (check("IDENTIFIER_NUM")) {
            match("IDENTIFIER_NUM", "Expected numeric variable after input prompt.");
        }
        else if (check("IDENTIFIER_TEXT")) {
            match("IDENTIFIER_TEXT", "Expected text variable after input prompt.");
        }
        else {
            error("Expected variable after input prompt.");
        }
    }

    private void parsePrint() {
        match("PRINT", "Expected 'print'.");

        if (check("STRING")) {
            match("STRING", "Expected string after print.");

            if (startsExpression()) {
                parseExpression();
            }
        }
        else {
            parseExpression();
        }
    }

    private void parseAssignment() {
        match("IDENTIFIER_NUM", "Expected numeric variable at beginning of assignment.");
        match("ASSIGN", "Expected '=' in assignment statement.");
        parseExpression();
    }

    private void parseIf() {
        match("IF", "Expected 'if'.");
        parseCondition();

        parseStatementList("ELSE", "ENDIF");

        if (check("ELSE")) {
            match("ELSE", "Expected 'else'.");
            parseStatementList("ENDIF");
        }

        match("ENDIF", "Expected 'endif' to close if statement.");
    }

    private void parseRepeat() {
        match("REPEAT", "Expected 'repeat'.");

        int savePosition = current;
        boolean isRepeatTimes = false;

        // Check whether the pattern is: repeat expression times
        if (startsExpression()) {
            parseExpression();
            if (check("TIMES")) {
                isRepeatTimes = true;
            }
        }

        // Form 1: repeat 5 times ... endrepeat
        if (isRepeatTimes) {
            match("TIMES", "Expected 'times' after repeat expression.");
            parseStatementList("ENDREPEAT");
            match("ENDREPEAT", "Expected 'endrepeat' to close repeat statement.");
        }
        // Form 2: repeat ... until condition endrepeat
        else {
            current = savePosition;
            parseStatementList("UNTIL");
            match("UNTIL", "Expected 'until' in repeat-until statement.");
            parseCondition();
            match("ENDREPEAT", "Expected 'endrepeat' to close repeat-until statement.");
        }
    }

    private void parseFromLoop() {
        match("FROM", "Expected 'from'.");
        parseExpression();
        match("TO", "Expected 'to' in from-to loop.");
        parseExpression();
        parseStatementList("ENDREPEAT");
        match("ENDREPEAT", "Expected 'endrepeat' to close from-to loop.");
    }

    private void parseCondition() {
        parseExpression();

        if (check("GE") || check("LE") || check("EQ") || check("NE") || check("GT") || check("LT")) {
            advance();
        }
        else {
            error("Expected relational operator in condition, example >, <, >=, <=, ==, !=.");
        }

        parseExpression();
    }

    private void parseExpression() {
        parseTerm();

        while (check("PLUS") || check("MINUS")) {
            advance();
            parseTerm();
        }
    }

    private void parseTerm() {
        parseFactor();

        while (check("TIMES_OP") || check("DIVIDE")) {
            advance();
            parseFactor();
        }
    }

    private void parseFactor() {
        if (check("NUMBER")) {
            match("NUMBER", "Expected number.");
        }
        else if (check("IDENTIFIER_NUM")) {
            match("IDENTIFIER_NUM", "Expected numeric variable.");
        }
        else if (check("LPAREN")) {
            match("LPAREN", "Expected '('.");
            parseExpression();
            match("RPAREN", "Expected ')' after expression.");
        }
        else {
            error("Expected number, numeric variable, or expression.");
        }
    }

    private boolean startsExpression() {
        return check("NUMBER") || check("IDENTIFIER_NUM") || check("LPAREN");
    }

    private boolean check(String tokenName) {
        if (isAtEnd()) {
            return false;
        }
        return peek().m_text.startsWith(tokenName + ":");
    }

    private Yytoken peek() {
        return tokens.get(current);
    }

    private Yytoken advance() {
        if (!isAtEnd()) {
            current++;
        }
        return tokens.get(current - 1);
    }

    private void match(String tokenName, String message) {
        if (check(tokenName)) {
            advance();
        }
        else {
            error(message);
        }
    }

    private boolean isAtEnd() {
        return current >= tokens.size();
    }

    private void error(String message) {
        String nearToken = isAtEnd() ? "EOF" : peek().toString();
        throw new RuntimeException(
                "\nSyntax Error near token " + current + ": " + nearToken + "\n" + message
        );
    }
}
